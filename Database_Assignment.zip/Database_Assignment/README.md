# Database Assignment — Classic Models

## Contents
- `answer.sql` — SQL solutions for all three JOIN questions.
- `screenshots/` — Add your own screenshots of the executed queries and result grids here.

## Database setup
This assignment uses the MySQL Classic Models sample database. Import the Classic Models SQL sample database into MySQL Workbench before running `answer.sql`.

The script selects the database with `USE classicmodels;` and then runs:
1. INNER JOIN: employees and offices.
2. LEFT JOIN: products and productlines.
3. RIGHT JOIN: customers and orders, limited to 10 rows.

## Screenshots required
Add these genuine screenshots from your own MySQL Workbench session to the `screenshots/` folder:
- `question1.png` — Question 1 SQL query and result grid.
- `question2.png` — Question 2 SQL query and result grid.
- `question3.png` — Question 3 SQL query and result grid (10 rows).

To capture on Windows, press `Win + Shift + S`, select the query and result area, then save each image using the filenames above.

Note: Screenshots are not included because they must show the results from your own MySQL Workbench session. Do not submit example or fabricated screenshots as proof of execution.
